package agh.ics.oop;

public enum Directions {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}
