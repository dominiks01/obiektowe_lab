package org.example;

public class Main {
    enum Direction {
        FORWARD,
        BACKWARD,
        RIGHT,
        LEFT
    }
}